const juegos = [
    {
        nombre: "Sims 4",
        
        imagen: "img/sims.jpeg",
        descripcion: "Los Sims es una serie de videojuegos de simulación social, diseñados por Will Wright y desarrollados inicialmente por Maxis y posteriormente por diferentes sellos de Electronic Arts."
    },
    {
        nombre: "stardew valley",
        
        imagen: "img/stardew.jpg",
        descripcion: "Stardew Valley es un videojuego indie de simulación de granja desarrollado por Eric ''ConcernedApe'' Barone y publicado por Chucklefish Games."
    },
    {
        nombre: "Pou",
        
        imagen: "img/pou.jpg",
        descripcion: "Pou es un videojuego del género de mascotas virtuales desarrollado por Paul Salameh."
    },
    {
        nombre: "Roblox",
        
        imagen: "img/roblox.jpg",
        descripcion: "Roblox es una plataforma de entretenimiento online para jugar que permite a las personas crear juegos para el público a través de herramienta digital de Roblox conocida como Roblox Estudio."
    },
    {
        nombre: "My Little Pony: magia",
       
        imagen: "img/mylitelpony.png",
        descripcion: "Antonio Herrera Pérez, más conocido como Junior H, es un cantante y compositor mexicano. Se especializa en el subgénero de corridos tumbados, popularizando el género con sus primeros álbumes de estudio."
    },
    {
        nombre: "Minecraft",
       
        imagen: "img/minecraft.jpeg",
        descripcion: "Minecraft es un videojuego tipo sandbox, su traducción literal sería “caja de arena” y es lo que representa la experiencia de juego."
    },
    {
        nombre: "Cat Snack Bar : Cat Food Games",
        
        imagen: "img/gatitoscocineros.jpeg",
        descripcion: "Este juego consta de hacar una franquicia de comida con gatitos cocineros."
    },
    {
        nombre: "Corazón de Melón",
        
        imagen: "img/cdm.jpg",
        descripcion: "Corazón de melón, es un videojuego otome diseñado y publicado por Beemoov, creado por Stéphanie Sala, más conocida como Chinomiko.​"
    },
    {
        nombre: "watermelon game monkey land",
        
        imagen: "img/Watermelon.jpeg",
        descripcion: "Suika Game es un videojuego de lógica japonés desarrollado y publicado por Aladdin X, que combina elementos de los juegos de rompecabezas de caída y fusión. "
    },
    {
        nombre: "GTA-5",
        
        imagen: "img/gta.jpg",
        descripcion: "Grand Theft Auto V es un videojuego de acción-aventura de mundo abierto desarrollado por el estudio escocés Rockstar North y distribuido por Rockstar Games.​"
    }
    
];

const juegosContainer = document.getElementById("juegos");
// Este es el map para poner los datos en el diseño
const juegoHtml = juegos.map(juego => {
    return `
        <div class="juegos">
            <img src="${juego.imagen}" alt="${juego.nombre}">
            <h3>${juego.nombre}</h3>

            <p>${juego.descripcion}</p>
        </div>
    `;
});

// Agregar los elementos HTML al contenedor
juegosContainer.innerHTML = juegoHtml.join("");
